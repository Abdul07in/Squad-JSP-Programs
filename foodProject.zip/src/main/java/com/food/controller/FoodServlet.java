package com.food.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.food.dao.FoodDaoImpl;
import com.food.pojo.Food;

@WebServlet("/FoodServlet")
public class FoodServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Integer foodId;
	private String foodName;
	private String foodType;
	private Double foodPrice;
	private Integer foodQuantity;
	private String foodCategory;
	private String foodDescription;
	private Integer foodRating;

	Food food = null;
	List<Food> flist = null;
	FoodDaoImpl fimpl = new FoodDaoImpl();
	RequestDispatcher rDispatcher = null;
	HttpSession session = null;

	public FoodServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String process = request.getParameter("process");
		session = request.getSession();
		if (process != null && process.equals("allFood")) {

			flist = fimpl.fetchAllFood();
			if (flist != null && !flist.isEmpty()) {
				session.setAttribute("flist", flist);
				response.sendRedirect("FoodList.jsp");
			} else {
				request.setAttribute("errmsg", "Menu is empty , Please try again later");
				rDispatcher = request.getRequestDispatcher("Home.jsp");
				rDispatcher.forward(request, response);
			}

		} else if (process != null && process.equals("updateFood")) {

			foodId = Integer.parseInt(request.getParameter("foodId"));
			food = fimpl.searchFoodById(foodId);
			session.setAttribute("foodObj", food);
			response.sendRedirect("UpdateFood.jsp");
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String process = request.getParameter("process");
		session = request.getSession();

		if (process != null && process.equals("addFood")) {

			foodName = request.getParameter("foodName");
			foodType = request.getParameter("foodType");
			foodPrice = Double.parseDouble(request.getParameter("foodPrice"));
			foodQuantity = Integer.parseInt(request.getParameter("foodQuantity"));
			foodCategory = request.getParameter("foodCategory");
			foodDescription = request.getParameter("foodDescription");
			foodRating = Integer.parseInt(request.getParameter("foodRating"));

			food = new Food(foodName, foodType, foodPrice, foodQuantity, foodCategory, foodDescription, foodRating);

			if (fimpl.addFood(food)) {
				request.setAttribute("msg", "Food Details added successfully");
				rDispatcher = request.getRequestDispatcher("AddFood.jsp");
				rDispatcher.forward(request, response);

			} else {
				request.setAttribute("errmsg", "Error While Adding Food Details");
				rDispatcher = request.getRequestDispatcher("AddFood.jsp");
				rDispatcher.forward(request, response);
			}

		} else if (process != null && process.equals("updateFoodItem")) {

			foodId = Integer.parseInt(request.getParameter("foodId"));
			foodName = request.getParameter("foodName");
			foodType = request.getParameter("foodType");
			foodPrice = Double.parseDouble(request.getParameter("foodPrice"));
			foodQuantity = Integer.parseInt(request.getParameter("foodQuantity"));
			foodCategory = request.getParameter("foodCategory");
			foodDescription = request.getParameter("foodDescription");
			foodRating = Integer.parseInt(request.getParameter("foodRating"));

			food = new Food(foodId, foodName, foodType, foodPrice, foodQuantity, foodCategory, foodDescription,
					foodRating);

			System.out.println(food);

		} else if (process != null && process.equals("searchFood")) {
			foodName = request.getParameter("foodName");
			List<Food> slist = fimpl.searchFoodByName(foodName);
			
			if(foodName == null || foodName.trim() == "" ) {
				session.setAttribute("slist", null);
				request.setAttribute("errmsg", "Entered Food Name Not Found");
				rDispatcher = request.getRequestDispatcher("Home.jsp");
				rDispatcher.forward(request, response);

				
			}else {

				if (slist != null && !slist.isEmpty()) {
					session.setAttribute("slist", slist);
					response.sendRedirect("Home.jsp");
				} else {
					session.setAttribute("slist", slist);
					request.setAttribute("errmsg", "Entered Food Name Not Found");
					rDispatcher = request.getRequestDispatcher("Home.jsp");
					rDispatcher.forward(request, response);

				}

			}
			
		}
	}

}
