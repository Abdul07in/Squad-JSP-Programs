package com.food.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.food.dao.CustomerImpl;
import com.food.pojo.Customer;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String customerName;
	private String customerAddress;
	private String customerEmail;
	private Long customerPhone;
	private String customerPassword;
	
	CustomerImpl cimpl = new CustomerImpl();
	Customer c = null;

	HttpSession session = null;
	RequestDispatcher rd = null;

	public RegisterServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String proccess = request.getParameter("proccess");

		if (proccess != null && proccess.equals("registerpage")) {
			customerName = request.getParameter("customerName");
			customerAddress = request.getParameter("customerAddress");
			customerEmail = request.getParameter("customerEmail");
			customerPhone = Long.parseLong(request.getParameter("customerPhone"));
			customerPassword = request.getParameter("customerPassword");
			
			if(cimpl.checkEmail(customerEmail) || cimpl.checkPhone(customerPhone) || cimpl.checkPassword(customerPassword)) {
				request.setAttribute("errmsg", "User Already Existed !!");
				rd = request.getRequestDispatcher("Registration.jsp");
				rd.forward(request, response);
			}else {
				c = new Customer(customerName, customerAddress, customerEmail, customerPhone, customerPassword);
				if(cimpl.addCustomer(c)) {
					request.setAttribute("msg", "SuccessFully Register");
					rd = request.getRequestDispatcher("Login.jsp");
					rd.forward(request, response);
				}else {
					request.setAttribute("errmsg", "User Already Existed !!");
					rd = request.getRequestDispatcher("Registration.jsp");
					rd.forward(request, response);
				}
			}

		}

	}

}
