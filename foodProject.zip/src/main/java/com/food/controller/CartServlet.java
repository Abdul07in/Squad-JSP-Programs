package com.food.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.food.dao.CartDaoImpl;
import com.food.dao.FoodDaoImpl;
import com.food.pojo.Cart;
import com.food.pojo.Food;

@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String email;
	
	CartDaoImpl cimpl = new CartDaoImpl();
	FoodDaoImpl fimpl = new FoodDaoImpl();
	Cart cart = null;
	Food food = null;
	HttpSession session = null;
	RequestDispatcher rd = null;

	public CartServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String process = request.getParameter("process");
		session = request.getSession();

		if (process != null && process.equals("addToCart")) {
			Integer foodId = Integer.parseInt(request.getParameter("foodId"));
			food = fimpl.searchFoodById(foodId);
			double subtotal = food.getFoodPrice() * 1;
			String customerEmail = (String) session.getAttribute("customerEmail");

			cart = new Cart(foodId, 1, food.getFoodPrice(), subtotal, customerEmail);

			if (cimpl.checkItem(foodId, customerEmail)) {
				request.setAttribute("msg", "This Item was already present so one more plate added");
			} else {
				if (cimpl.addCart(cart)) {
					request.setAttribute("msg", "Item Added to Cart Sucessfully");
				} else {
					request.setAttribute("errmsg", "Error While Adding Food Details");
				}
			}

			List<Food> flist = fimpl.fetchAllFood();
			session.setAttribute("flist", flist);
			rd = request.getRequestDispatcher("FoodList.jsp");
			rd.forward(request, response);
		}
		if(process != null && process.equals("showCart")) {
			email = (String) session.getAttribute("customerEmail");
			List<Cart> clist = cimpl.showMyCart(email);
			
			if(clist != null && !clist.isEmpty()) {
				session.setAttribute("clist", clist);
				request.setAttribute("msg", "You Have " + clist.size() + " items in your cart.");
				rd = request.getRequestDispatcher("MyCart.jsp");
				rd.forward(request, response);
			}else {
				session.setAttribute("clist", clist);
				request.setAttribute("errmsg", "Your Cart is Empty, please add items to view Cart.");
				rd = request.getRequestDispatcher("MyCart.jsp");
				rd.forward(request, response);
			}
			
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
