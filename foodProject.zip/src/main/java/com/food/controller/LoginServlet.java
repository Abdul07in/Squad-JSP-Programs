package com.food.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.food.dao.CustomerImpl;
import com.food.dao.LoginDaoImpl;
import com.food.pojo.Customer;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private String username;
    private String password;
    private String login;
    LoginDaoImpl limpl = new LoginDaoImpl();
    CustomerImpl cimpl = new CustomerImpl();
    HttpSession session = null;
    RequestDispatcher rd = null;
    
	
	
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String proccess = request.getParameter("proccess");
		if(proccess != null && proccess.equals("logout")) {
			session = request.getSession();
			session.removeAttribute(login);
			session.invalidate();
			request.setAttribute("msg", "Successfully Logged Out");
			rd = request.getRequestDispatcher("Home.jsp");
			rd.forward(request, response);
		}
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String proccess = request.getParameter("proccess");
		if(proccess != null && proccess.equals("loginpage")) {
			
			username = request.getParameter("username");
			password = request.getParameter("password");
			session = request.getSession();
			
			if(limpl.checkAdmin(username, password)) {
				login = "admin";
				session.setAttribute("login", login);
				request.setAttribute("msg", "Successfully Logged in as Admin");
				rd = request.getRequestDispatcher("Home.jsp");
				rd.forward(request, response);
				
			}else if(limpl.checkCustomer(username, password)) {
				login = "customer";
				session.setAttribute("login", login);
				Customer c = cimpl.searchCustomerByEmail(username);
				session.setAttribute("customerEmail", c.getCustomerEmail());
				request.setAttribute("msg", "Welcome to our website " + c.getCustomerName());
				rd = request.getRequestDispatcher("Home.jsp");
				rd.forward(request, response);
				
			}else {
				login = null;
				request.setAttribute("errmsg", "Please Check UserName and Password");
				rd = request.getRequestDispatcher("Login.jsp");
				rd.forward(request, response);
			}
			
		}
	}

}
